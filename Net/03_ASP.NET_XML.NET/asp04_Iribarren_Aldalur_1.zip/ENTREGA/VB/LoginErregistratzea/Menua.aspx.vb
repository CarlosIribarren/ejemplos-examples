﻿Public Class Menua
    Inherits System.Web.UI.Page

End Class