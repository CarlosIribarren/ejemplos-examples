﻿Public Class Hasiera
    Inherits System.Web.UI.Page

End Class